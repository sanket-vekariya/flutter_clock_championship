#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/home/sanketvekariya/flutter"
export "FLUTTER_APPLICATION_PATH=/home/sanketvekariya/Downloads/GitHub_Reference/flutter_clock/sanket_clock"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_FRAMEWORK_DIR=/home/sanketvekariya/flutter/bin/cache/artifacts/engine/ios"
